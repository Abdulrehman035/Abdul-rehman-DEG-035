from dataclasses import dataclass


@dataclass
class Mountain:
    name: str
    elevation: int

Result = Mountain("K2", 420000)

print(type(str(Result)))
print(str(Result))